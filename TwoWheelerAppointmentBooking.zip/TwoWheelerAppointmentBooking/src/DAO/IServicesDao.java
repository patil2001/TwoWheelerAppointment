package DAO;

import java.sql.SQLException;
import java.util.List;

import Entity.Services;
import Exception.ServiceNotFoundException;

public interface IServicesDao {
	public int addService(Services serv) throws ClassNotFoundException,SQLException;
	public int updateService(Services serv) throws ClassNotFoundException,SQLException,ServiceNotFoundException;
	public int deleteService(int servId) throws ClassNotFoundException,SQLException,ServiceNotFoundException;
	public Services viewServices(int servId) throws ClassNotFoundException,SQLException,ServiceNotFoundException;
	public List<Services> viewServices() throws ClassNotFoundException,SQLException,ServiceNotFoundException;
}
