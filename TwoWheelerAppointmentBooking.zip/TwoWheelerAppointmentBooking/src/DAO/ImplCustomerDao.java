package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import DBConnect.DBconnection;
import Entity.Customer;
import Exception.CustomerNotFoundException;

public class ImplCustomerDao implements ICustomerDao{

	private static Connection con;
	
	@Override
	public int addCustomer(Customer cust) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		con=DBConnect.DBconnection.createConnection();
		
		String query="INSERT into Customer( , , , ) values (?,?,?,?)";
		
		PreparedStatement prepstmt=con.prepareStatement(query);
		prepstmt.setInt(1,cust.getCustId());
		prepstmt.setString(2,cust.getName());
		prepstmt.setString(3,cust.getAddress());
		prepstmt.setString(4,cust.getContactNo());
		
		int res=prepstmt.executeUpdate();
		
		DBconnection.closeConnection();
		return res;
	}

	@Override
	public int updateCustomer(Customer cust) throws ClassNotFoundException, SQLException, CustomerNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteCustomer(int custId) throws ClassNotFoundException, SQLException, CustomerNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer viewCustomer(int custId) throws ClassNotFoundException, SQLException, CustomerNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> viewCustomer() throws ClassNotFoundException, SQLException, CustomerNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
