module TwoWheelerAppointmentBooking {
	requires java.sql;
}