package Entity;

import java.util.Objects;

public class Technician {

		private int techId;
		private String name;
		private String address;
		private String contactNo;
		public String getName() {
			return name;
		}
		public Technician() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Technician(int techId, String name, String address, String contactNo) {
			super();
			this.techId = techId;
			this.name = name;
			this.address = address;
			this.contactNo = contactNo;
		}

		@Override
		public int hashCode() {
			return Objects.hash(address, contactNo, name, techId);
		}
		public void setName(String name) {
			this.name = name;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Technician other = (Technician) obj;
			return Objects.equals(address, other.address) && Objects.equals(contactNo, other.contactNo)
					&& Objects.equals(name, other.name) && techId == other.techId;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getContactNo() {
			return contactNo;
		}
		public void setContactNo(String contactNo) {
			this.contactNo = contactNo;
		}
		public int getTechId() {
			return techId;
		}
		@Override
		public String toString() {
			return "Technician [techId=" + techId + ", name=" + name + ", address=" + address + ", contactNo="
					+ contactNo + "]";
		}
		
		
		
}
