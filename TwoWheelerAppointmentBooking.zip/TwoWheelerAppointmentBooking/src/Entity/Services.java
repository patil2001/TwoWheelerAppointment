package Entity;

import java.util.Objects;

public class Services {
	
	private int servId;
	private String description;
	private float charges;
	private Technician techId;
	public String getDescription() {
		return description;
	}
	
	
	public Services() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Services(int servId, String description, float charges, Technician techId) {
		super();
		this.servId = servId;
		this.description = description;
		this.charges = charges;
		this.techId = techId;
	}


	@Override
	public int hashCode() {
		return Objects.hash(charges, description, servId, techId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Services other = (Services) obj;
		return Float.floatToIntBits(charges) == Float.floatToIntBits(other.charges)
				&& Objects.equals(description, other.description) && servId == other.servId
				&& Objects.equals(techId, other.techId);
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public float getCharges() {
		return charges;
	}
	public void setCharges(float charges) {
		this.charges = charges;
	}
	public int getServId() {
		return servId;
	}
	public Technician getTechId() {
		return techId;
	}
	@Override
	public String toString() {
		return "VehicleServices [servId=" + servId + ", description=" + description + ", charges=" + charges
				+ ", techId=" + techId + "]";
	}
	
	

}
