package Exception;

public class TechnicianNotFoundException extends Exception{

	public TechnicianNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TechnicianNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

		
}
