package Exception;

public class ServiceNotFoundException extends Exception {

	public ServiceNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
