package DAO;

import java.sql.SQLException;
import java.util.List;

import Entity.Customer;
import Exception.CustomerNotFoundException;

public interface ICustomerDao {
	public int addCustomer(Customer cust) throws ClassNotFoundException,SQLException;
	public int updateCustomer(Customer cust) throws ClassNotFoundException,SQLException,CustomerNotFoundException;
	public int deleteCustomer(int custId) throws ClassNotFoundException,SQLException,CustomerNotFoundException;
	public Customer viewCustomer(int custId) throws ClassNotFoundException,SQLException,CustomerNotFoundException;
	public List<Customer> viewCustomer() throws ClassNotFoundException,SQLException,CustomerNotFoundException;
	
}
