package Entity;

import java.util.Objects;

public class Appointment {

		private int AptId;
		private Customer custId;
		private Technician techId;
		private Services servId;
		public Customer getCustId() {
			return custId;
		}
		
		public Appointment() {
			super();
			// TODO Auto-generated constructor stub
		}
		

		@Override
		public int hashCode() {
			return Objects.hash(AptId, custId, servId, techId);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Appointment other = (Appointment) obj;
			return AptId == other.AptId && Objects.equals(custId, other.custId) && Objects.equals(servId, other.servId)
					&& Objects.equals(techId, other.techId);
		}

		public Appointment(int aptId, Customer custId, Technician techId, Services servId) {
			super();
			AptId = aptId;
			this.custId = custId;
			this.techId = techId;
			this.servId = servId;
		}
		

		public void setCustId(Customer custId) {
			this.custId = custId;
		}
		public Technician getTechId() {
			return techId;
		}
		public void setTechId(Technician techId) {
			this.techId = techId;
		}
		public Services getServId() {
			return servId;
		}
		public void setServId(Services servId) {
			this.servId = servId;
		}
		public int getAptId() {
			return AptId;
		}
		@Override
		public String toString() {
			return "Appointment [AptId=" + AptId + ", custId=" + custId + ", techId=" + techId + ", servId=" + servId
					+ "]";
		}
		
		
}
