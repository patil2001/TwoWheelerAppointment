package DAO;

import java.sql.SQLException;
import java.util.List;

import Entity.Technician;
import Exception.TechnicianNotFoundException;



public interface ITechnicianDao {
	public int addTechnician(Technician tech) throws ClassNotFoundException,SQLException;
	public int updateTechnician(Technician tech) throws ClassNotFoundException,SQLException,TechnicianNotFoundException;
	public int deleteTechnician(int techId) throws ClassNotFoundException,SQLException,TechnicianNotFoundException;
	public Technician viewTechnicain(int techId) throws ClassNotFoundException,SQLException,TechnicianNotFoundException;
	public List<Technician> viewTechnician() throws ClassNotFoundException,SQLException,TechnicianNotFoundException;
}
