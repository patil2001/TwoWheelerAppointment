package DBConnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBconnection {
	private static Connection connection;
	
	public static Connection createConnection() throws ClassNotFoundException,SQLException
	{
		ResourceBundle resMySql=ResourceBundle.getBundle("mysql");
		
		String url=resMySql.getString("url");
		String user=resMySql.getString("user");
		String pass=resMySql.getString("pass");
		String driver=resMySql.getString("driver");
		
		Class.forName(driver);
		
		connection=DriverManager.getConnection(url,user,pass);
		
		return connection;
		
	}
	
	public static void closeConnection() throws SQLException
	{
		connection.close();
	}
	
}
